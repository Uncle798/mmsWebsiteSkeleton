import { c as create_ssr_component } from "../../../chunks/ssr.js";
import "../../../chunks/client.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<form method="post"><button data-svelte-h="svelte-gb8s7r">Sign Out</button></form>`;
});
export {
  Page as default
};
