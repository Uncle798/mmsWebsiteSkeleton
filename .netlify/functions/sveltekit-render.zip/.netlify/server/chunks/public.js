const PUBLIC_COMPANY_NAME = "Moscow Mini Storage";
const PUBLIC_ANVIL_EMAIL = "hello@useanvil.com";
export {
  PUBLIC_COMPANY_NAME as P,
  PUBLIC_ANVIL_EMAIL as a
};
